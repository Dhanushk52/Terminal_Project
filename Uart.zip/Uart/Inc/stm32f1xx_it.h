#ifndef __STM32F1xx_IT_H
#define __STM32F1xx_IT_H

void SysTick_Handler(void);

#endif
